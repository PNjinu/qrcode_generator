# QR code generator
## Simple free to use qr code generator

Just input any string and you get a qr code that can be downloaded as a png or svg.